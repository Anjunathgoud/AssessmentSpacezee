import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class EnglishToFrenchTranslator {

    public static void main(String[] args) {
        try {
            String inputFilePath = "C:/Users/HP/Desktop/input.txt";
            String outputFilePath = "C:/Users/HP/Desktop/output.txt";
            
            Map<String, String> dictionary = getEnglishToFrenchDictionary();
    
            BufferedReader reader = new BufferedReader(new FileReader(inputFilePath));
            FileWriter writer = new FileWriter(outputFilePath);
            
            String line = reader.readLine();
            while (line != null) {
                String[] words = line.split(" ");
                for (int i = 0; i < words.length; i++) {
                    String word = words[i];
                    if (dictionary.containsKey(word)) {
                        words[i] = dictionary.get(word);
                    }
                }
                String translatedLine = String.join(" ", words);
                writer.write(translatedLine + "\n");
                line = reader.readLine();
            }
            reader.close();
            writer.close();
            
            System.out.println("Translation completed successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
}
 private static Map<String, String> getEnglishToFrenchDictionary() {
        Map<String, String> dictionary = new HashMap<>();
        dictionary.put("cat", "chat");
        dictionary.put("dog", "chien");
        dictionary.put("bird", "oiseau");
        dictionary.put("house", "maison");     
        dictionary.put("hello", "bonjour");
        dictionary.put("world", "monde");
        dictionary.put("java", "java");
        // add more words to the dictionary as needed
        return dictionary;
    }

}

